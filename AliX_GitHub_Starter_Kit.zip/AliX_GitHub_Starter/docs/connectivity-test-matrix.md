# ماتریس آزمون Connectivity Manager

**هدف:** اثبات اینکه هر مسیر فقط برای endpoint مجاز، با هویت خروجی معلوم و TLS معتبر کار می‌کند و failure آن به سفارش تکراری یا دورزدن policy منجر نمی‌شود.

## ماتریس transport

| Transport | آزمون پایه | آزمون امنیتی | معیار PASS | وضعیت اجرا |
|---|---|---|---|---|
| Direct | DNS، TLS، REST و WebSocket در صورت نیاز | certificate validation، egress IP و timeout | endpoint قابل دسترسی؛ TLS معتبر؛ egress ثبت‌شده | `NOT RUN` |
| HTTP/HTTPS Proxy | auth، REST/WebSocket، latency و reconnect | جلوگیری از log credential، TLS end-to-end | فقط proxy تأییدشده؛ timeout/retry محدود | `NOT RUN` |
| SOCKS Proxy | اتصال SOCKS5 در کتابخانه/نسخهٔ واقعی، DNS behavior، REST/WebSocket | secret handling، egress identity و عدم downgrade | مسیر در نسخهٔ واقعی سازگار و قابل ممیزی | `NOT RUN` |
| VPN | اتصال/قطع، route table، DNS و egress IP | route leak، key permissions، kill behavior | egress مورد انتظار؛ قطع تونل منجر به fail-closed | `NOT RUN` |
| SSH Tunnel | port forwarding، reconnect و endpoint binding | key permissions، host-key verification، port scope | فقط مقصد تعریف‌شده؛ SSH host key verify شده | `NOT RUN` |

## سناریوهای سراسری

- [ ] خطای DNS یا TLS؛ هیچ ارسال سفارشی صورت نگیرد.
- [ ] احراز هویت ناموفق؛ circuit breaker فعال شود و credential در log دیده نشود.
- [ ] rate limit / HTTP 429؛ backoff با سقف تلاش و احترام به quota اجرا شود.
- [ ] مسیر اصلی خراب؛ تنها مسیر جایگزین `approved` انتخاب شود.
- [ ] route failover موجب تغییر IP شود؛ egress allowlist/identity دوباره بررسی شود.
- [ ] order request timeout و پاسخ نامعلوم؛ هیچ route switch یا retry سفارشی تا reconciliation مجاز نیست.
- [ ] REST در دسترس ولی WebSocket قطع؛ feature freshness و سیاست توقف بررسی شود.
- [ ] قطع کامل VPN/SSH؛ سیستم به مسیر مستقیم غیرمجاز fallback نکند.
- [ ] restart worker در حین اتصال؛ order state از صرافی reconciliation شود.
- [ ] endpoint دادهٔ جانشین schema/واحد/تازگی متفاوت دارد؛ Data Quality Gate آن را رد کند.

## شواهد اجباری هر آزمون

برای هر تست، این موارد در report ثبت شوند: `test_id`, transport version, service/endpoint category, environment, start/end timestamp, egress IP (در صورت مجازبودن)، TLS result، latency p50/p95، failure reason، retry/failover trace، order reconciliation outcome، commit SHA و مسئول بررسی. هرگونه API key، credential، payload شخصی یا IP حساس نباید در گزارش عمومی ثبت شود.

## سیاست پذیرش

- transport فقط در environment مورد آزمون `SUPPORTED` می‌شود؛ معماری از قبل پشتیبانی واقعی تمام کتابخانه‌ها را فرض نمی‌کند.
- مسیر ناموفق یا مبهم `REJECTED` است؛ fallback خودکار آن را دور نمی‌زند.
- مسیر معاملاتی و مسیر دریافت داده ممکن است policyهای متفاوت داشته باشند.
- اتصال موفق معیار صحت یا مجوز داده نیست؛ provider باید جداگانه در `data-provider-registry.md` تأیید شود.
