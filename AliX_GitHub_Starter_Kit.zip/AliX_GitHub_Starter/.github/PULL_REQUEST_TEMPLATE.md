## هدف تغییر
- Issue / Phase:
- مسئله‌ای که حل می‌شود:

## نوع تغییر
- [ ] معماری / ADR
- [ ] صرافی یا order lifecycle
- [ ] Connectivity Manager
- [ ] External data / NLP
- [ ] Risk Engine / Kill Switch
- [ ] تست / مستندات

## شواهد و پذیرش
- [ ] معیارهای پذیرش قابل آزمون‌اند.
- [ ] CI سبز است.
- [ ] تست‌های unit/contract/recovery متناسب اجرا شده‌اند.
- [ ] رفتار timeout، retry، failover و rollback مستند شده است.

## امنیت و مجوز
- [ ] هیچ secret واقعی به diff، log یا artifact اضافه نشده است.
- [ ] Data/license impact بررسی و registry به‌روز شده است.
- [ ] هیچ provider یا transport برای عبور از محدودیت/سیاست استفاده نمی‌شود.

## ریسک rollout
- اثر بر سفارش، داده، ریسک و حساب‌ها:
- روش rollback:
- شواهد / لینک CI:
- ADR مرتبط:
