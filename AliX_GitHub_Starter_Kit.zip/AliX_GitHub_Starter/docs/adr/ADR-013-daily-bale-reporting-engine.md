# ADR-013: Daily Reporting Engine and Bale Notifications

- **Status:** Accepted for architecture; current Bale API details and SDK remain to be verified in Phase 0/1.
- **Decision:** A read-only Reporting Engine produces the daily operational report at 07:00 in the configured IANA timezone and sends text plus charts through a Bale Bot API adapter to an allowlisted chat.

## Report content
Daily and cumulative realized/unrealized/net PnL, fees, equity curve, trade counts and outcomes, open-order status, exposure, drawdown, absolute-cap status, Kill Switch, Risk Gate rejections, data quality/freshness, connectivity, model/config version, service health and delivery timestamp.

## Safety and reliability
- The engine reads reconciled Freqtrade DB/exchange snapshots and Decision Ledger only; it cannot submit orders or modify risk policy.
- `reporting.timezone` is an IANA TZ database name; `Asia/Tehran` is the initial default and is owner-configurable.
- Bot token is stored only in local secret management. Chat ID is allowlisted; secrets and unnecessary sensitive account details are excluded from reports/logs.
- Incoming Bale messages do not authorize trading or modify live mode.
- Report ids and source snapshot hashes are stored; retries are bounded and idempotent. Unreconciled data is labeled DEGRADED rather than shown as final PnL.
- A third-party SDK is not approved until its license, provenance, dependencies and API contract are reviewed.

## Acceptance
The 07:00 schedule, timezone/restart behaviour, text/image/document delivery, unauthorized recipient, API downtime, invalid token, duplicate run, file-size failure, log redaction, PnL reconciliation and fallback are covered by tests. Full-data reports are promoted only after backtest/paper validation and release approval.
