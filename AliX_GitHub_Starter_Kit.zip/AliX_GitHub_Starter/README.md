# AliX — AI-Driven Trading System Blueprint

**وضعیت:** مخزن آغازین معماری و حاکمیت پروژه؛ نه بستهٔ آمادهٔ معامله.  
**نسخهٔ مستندات:** MRD 0.5 · Roadmap 1.3  
**اصل معماری:** Freqtrade موتور چرخهٔ معامله باقی می‌ماند؛ داده، مدل، اتصال و ریسک به‌صورت لایه‌های ماژولار توسعه می‌یابند. هیچ کد یا کلید معاملاتی واقعی در این مخزن اولیه وجود ندارد.

## مرجع اسناد

- [`docs/MRD.md`](docs/MRD.md): مرجع معماری، قراردادها، امنیت، منابع و ADRها.
- [`docs/ROADMAP.md`](docs/ROADMAP.md): فازهای صفر تا ۱۲، معیارهای پذیرش و انتقال کنترل‌شده به محیط محلی.
- [`docs/data-provider-registry.md`](docs/data-provider-registry.md): مرجع مجوزها، endpoints، rate limits و وضعیت هر منبع.
- [`docs/connectivity-test-matrix.md`](docs/connectivity-test-matrix.md): ماتریس مسیرهای اتصال و سناریوهای آزمون.
- [`docs/adr/`](docs/adr/): ADRهای مجزا برای بازبینی در PR.
- [`docs/phase-reports/`](docs/phase-reports/): شواهد پذیرش هر فاز.
- [`docs/reporting/daily-report-spec.md`](docs/reporting/daily-report-spec.md): قرارداد گزارش گرافیکی روزانهٔ بله.
- [`docs/governance/owner-directives/TEMPLATE.md`](docs/governance/owner-directives/TEMPLATE.md): ثبت تغییرات رسمی مالک.
- [`docs/adr/ADR-012-project-governance-owner-authority.md`](docs/adr/ADR-012-project-governance-owner-authority.md) و [`ADR-013`](docs/adr/ADR-013-daily-bale-reporting-engine.md): حاکمیت مالک و گزارش‌دهی بله.

نسخه‌های Word در `docs/exports/` صرفاً خروجی‌های خواندنی‌اند. **Markdown مرجع اصلی (source of truth) است** و تغییرات معماری باید ابتدا در Markdown ثبت شوند.

## روش توسعه در GitHub

1. برای هر کار یک Issue با فاز مرتبط بسازید و معیار پذیرش آن را به آزمون‌پذیرترین شکل بنویسید.
2. در شاخه‌ای کوتاه و موضوعی مانند `docs/connectivity-matrix` یا `feat/provider-registry` کار کنید.
3. تغییرات را با Pull Request وارد `main` کنید؛ CI باید سبز باشد و تغییرات ریسک/صرافی/اتصال یک reviewer مالک حوزه داشته باشند.
4. هر تغییر وابسته به تصمیم معماری، ADR مرتبط را ایجاد یا به‌روزرسانی می‌کند.
5. هر فاز با یک گزارش `GO / NO-GO / CONDITIONAL GO` بسته می‌شود، نه فقط با merge شدن کد.

## سیاست اتصال و داده

- Connectivity Manager مسیرهای Direct، HTTP(S) Proxy، SOCKS Proxy، VPN و SSH Tunnel را صرفاً در محدودهٔ مجاز و قابل ممیزی مدیریت می‌کند.
- هیچ route-switch یا retry کور پس از timeout سفارش مجاز نیست؛ ابتدا باید وضعیت سفارش reconciliation شود.
- منابع خارجی فقط از API/RSS مجاز و مطابق شرایط استفاده وارد می‌شوند. فهرست providerها به معنی فعال‌بودن یا داشتن مجوز نیست.
- TradingView تا ثبت مجوز صریح برای کاربرد non-display/algorithmic در تصمیم معامله، `blocked_for_ai_trading` باقی می‌ماند.
- هرگز secret، کلید API، VPN/SSH credential، config واقعی یا دادهٔ تاریخی دارای محدودیت بازتوزیع را commit نکنید.

## CI و امنیت

Workflow اولیه فقط کیفیت مستندات و وجود فایل‌های ضروری را بررسی می‌کند. با اضافه شدن کد، تست‌های unit/contract/integration و اسکن dependency باید جداگانه اضافه شوند. CI نباید کلید صرافی واقعی، secret تونل یا دسترسی به حساب زنده داشته باشد.

## حاکمیت مالک و گزارش روزانه

مالک مرجع نهایی تصمیم‌های داخلی است؛ هر Owner Directive باید با اثر ریسک/امنیت و commit در Git ثبت شود. درخواست live فقط از مسیر Release Authorization و پس از عبور gateهای اجباری اجرا می‌شود. گزارش روزانه در ۰۷:۰۰ منطقهٔ زمانی پیکربندی‌شده از طریق Bale Bot API به chat allowlist شده ارسال می‌شود؛ bot token و chat ID هرگز commit نمی‌شوند و بله در نسخهٔ اول کانال اطلاع‌رسانی یک‌طرفه است.

## انتقال به محیط محلی

انتقال فقط از یک tag/commit بازبینی‌شده و فایل dependency lock انجام شود. secrets محلی از secret manager یا محیط امن تزریق شوند. ابتدا mock/contract tests، سپس backtest، dry-run/paper و فقط پس از عبور همهٔ gateها اجرای زندهٔ محدود مجاز است. GitHub-hosted runner محل اجرای معاملات واقعی نیست.

## شروع سریع برای مالک مخزن

- حفاظت از شاخهٔ `main` را فعال کنید.
- Pull request review و Actions را اجباری کنید.
- Issueها را بر اساس فازهای Roadmap بسازید.
- URL و commit آداپتور Novaryn را محرمانه‌زدایی و در ADR/registry ثبت کنید؛ اگر repository خصوصی است، دسترسی به آن را محدود نگه دارید.
- پیش از نوشتن کد معاملاتی، Phase 0 و سپس Phase 1 را با evidence ببندید.
