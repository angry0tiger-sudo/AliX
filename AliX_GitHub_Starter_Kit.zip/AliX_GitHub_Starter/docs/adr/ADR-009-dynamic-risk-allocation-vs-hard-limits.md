# ADR-009: Dynamic Risk Allocation vs. Hard Limits

**وضعیت:** پذیرفته‌شده برای معماری؛ فعال‌سازی live مشروط به OOS validation و fault injection.

## تصمیم

FreqAI و لایه‌های رژیم بازار/Meta-Labeling می‌توانند به‌صورت پویا بودجهٔ روزانه، اندازهٔ موقعیت و حد ضرر پیشنهادی را با توجه به regime، ATR، confidence کالیبره‌شده، عدم‌قطعیت مدل، هزینه‌های اجرا و exposure محاسبه کنند. Risk Gate قطعی و Risk Supervisor مستقل خروجی را اعتبارسنجی می‌کنند.

مالک در فاز صفر فقط Absolute Capital Protection Limits و semantics آن‌ها (مرجع equity، پنجرهٔ محاسبه و رفتار halt) را تصویب می‌کند. این سقف‌ها immutable و خارج از اختیار مدل هستند.

## قیود

- مدل نمی‌تواند سقف مطلق یا Kill Switch را تغییر دهد یا خاموش کند.
- خروجی ناقص/نامعتبر، دادهٔ stale/gapped یا ریسک غیرقابل‌محاسبه به رد ورود می‌انجامد.
- high ATR، uncertainty بالا، افت calibration یا هزینهٔ اجرای غیرعادی باید باعث کاهش exposure یا رد پیشنهاد شود.
- stop-loss قیمت تضمین‌شدهٔ اجرا نیست؛ gap و slippage واقعی می‌تواند زیان را از مقدار تخمینی بیشتر کند.

## پذیرش

Walk-forward/OOS و fault injection باید تغییر رژیم، ATR جهشی، confidence پایین، outage مدل، crash و trigger سقف را پوشش دهد. تا عبور، allocator در shadow/paper است.
