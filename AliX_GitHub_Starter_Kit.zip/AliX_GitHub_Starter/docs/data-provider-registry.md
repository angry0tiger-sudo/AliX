# ثبت منابع داده خارجی (External Data Provider Registry)

**مسئولیت:** مالکیت مجوز، endpoint رسمی، نرخ درخواست، کیفیت، provenance و معیار فعال‌سازی هر منبع.  
**قانون:** حضور در این فهرست به معنی مجازبودن استفاده یا فعال‌بودن provider نیست. فقط وضعیت `approved` اجازهٔ فعال‌سازی می‌دهد.

## وضعیت‌ها

- `approved`: شرایط استفاده و مورد کاربرد AliX بررسی و مستند شده، آزمون قرارداد/کیفیت سبز است.
- `conditional`: کاندید اتصال است، اما تأیید طرح API، لایسنس، retention، قیمت یا تست هنوز ناقص است.
- `blocked_for_ai_trading`: تا تغییر مستند شرایط یا اخذ مجوز صریح، در تصمیم خودکار معامله استفاده نشود.
- `rejected`: ریسک حقوقی/فنی یا هزینه برای پروژه قابل قبول نیست.

## رجیستری اولیه

| خانواده | منبع / connector | مستندات مرجع | وضعیت اولیه | شروط فعال‌سازی |
|---|---|---|---|---|
| تحلیل بازار | TradingView | https://www.tradingview.com/policies/ | `blocked_for_ai_trading` | مجوز کتبی صریح برای non-display/algorithmic use، نگهداری مدرک مجوز، بازبینی حقوقی |
| بازار | CoinGecko | https://www.coingecko.com/en/api/pricing | `conditional` | طرح، نرخ درخواست، استفاده تجاری، retention و حقوق نمایش/پردازش بررسی شود |
| بازار | CoinMarketCap | https://coinmarketcap.com/api/documentation/ | `conditional` | API key در secret store، tier/rate limits و شرایط استفاده تأیید شود |
| بازار / مشتقات | CoinGlass | https://docs.coinglass.com/reference/endpoint-overview | `conditional` | endpointها، پلن، retention و پوشش بازار تأیید شود |
| On-chain | Provider منتخب پس از ارزیابی | TBD | `conditional` | chain/asset coverage، latency، provenance، مجوز و نرخ باید مستند شود |
| نهنگ‌ها | Whale Alert | https://developer.whale-alert.io/api-account/documentation | `conditional` | API plan، rate limits، تعریف رویداد، retention و هزینه تأیید شود |
| خبر | RSS feedها / News API | https://newsapi.org/docs | `conditional` به‌ازای هر ناشر | RSS/API رسمی، حقوق نگهداری snapshot، attribution و پردازش NLP بررسی شود |
| تقویم | Economic Calendar provider | TBD | `conditional` | منبع رسمی، زمان‌بندی، revisions، مجوز دادهٔ تاریخی مشخص شود |
| شبکهٔ اجتماعی | X API | https://help.x.com/en/rules-and-policies/x-api | `conditional` | دسترسی و endpoint مجاز، قواعد نگهداری/حذف، quota و مورد کاربرد تأیید شود |
| پیام‌رسان | Telegram API / Bot API | https://core.telegram.org/api | `conditional` | فقط bot/API و کانال‌های قابل‌دسترسی مجاز؛ private data یا scraping ممنوع |
| منابع ایرانی | وب‌سایت خبری/تحلیلی فارسی، به‌ازای هر منبع | URL رسمی هر ناشر | `conditional` | API یا RSS مجاز، حقوق پردازش/ذخیره، attribution و زمان انتشار بررسی شود |

## رکورد الزامی برای هر connector

هر منبع فعال یا در حال ارزیابی باید یک ردیف تکمیلی (در PR یا فایل اختصاصی) با فیلدهای زیر داشته باشد:

- `provider_id`, `owner`, `status`, `reviewed_at`, `reviewed_by`
- endpoint/API/RSS رسمی، نسخهٔ API و لینک شرایط استفاده
- مورد کاربرد مجاز (`display`, `analytics`, `nlp`, `automated_trading`) با علامت مجاز/غیرمجاز
- tier/قیمت، rate limit، pagination، retry policy و quota
- حقوق نگهداری متن/داده، retention، حذف، بازتوزیع و attribution
- semantics زمان: `event_time`, `published_at`, `ingested_at`, `available_at`, `processed_at`
- schema/version، units/currency، symbol mapping و coverage
- Freshness/SLO، روش cache، fallback و circuit breaker
- contract tests، fixture/snapshot مجاز، checksum و نتیجهٔ Data Quality Gate
- threat model، نوع credential، محل secret mount و روش rotation

## قوانین سراسری

1. فقط API رسمی، RSS مجاز یا قرارداد معتبر استفاده شود. scraping غیرمجاز، دورزدن دسترسی یا reuse کوکی شخصی ممنوع است.
2. خطای API با تغییر حساب/پراکسی برای عبور از quota حل نمی‌شود؛ backoff و circuit breaker اجرا می‌شود.
3. دادهٔ بیرونی منبع حقیقت سفارش/fill/balance نیست. reconciliation از صرافی معامله‌گر انجام می‌شود.
4. news/social features فقط با point-in-time join قابل استفاده‌اند؛ داده‌ای که پس از `decision_time` در دسترس شده باشد وارد تاریخچه نمی‌شود.
5. provider تا زمانی که وضعیت آن `approved` نیست، در مدل زنده غیرفعال می‌ماند.
