#!/usr/bin/env python3
"""Dependency-free structural checks for the initial AliX documentation repo."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_FILES = [
    "README.md",
    "CONTRIBUTING.md",
    "SECURITY.md",
    "docs/MRD.md",
    "docs/ROADMAP.md",
    "docs/data-provider-registry.md",
    "docs/connectivity-test-matrix.md",
    "docs/adr/ADR-009-dynamic-risk-allocation-vs-hard-limits.md",
    "docs/adr/ADR-010-connectivity-manager.md",
    "docs/adr/ADR-011-external-data-provider-registry.md",
]
REQUIRED_CONTENT = {
    "docs/MRD.md": ["Connectivity Manager", "External Data", "ADR-009", "ADR-010", "ADR-011", "Data Quality Gate"],
    "docs/ROADMAP.md": ["فاز ۱", "فاز ۶", "GitHub", "سقف محافظتی مطلق", "TradingView"],
    "docs/connectivity-test-matrix.md": ["Direct", "HTTP/HTTPS Proxy", "SOCKS Proxy", "VPN", "SSH Tunnel"],
    "docs/data-provider-registry.md": ["CoinGecko", "CoinMarketCap", "CoinGlass", "Whale Alert", "blocked_for_ai_trading"],
}

errors = []
for rel in REQUIRED_FILES:
    if not (ROOT / rel).is_file():
        errors.append(f"Missing required file: {rel}")
for rel, snippets in REQUIRED_CONTENT.items():
    p = ROOT / rel
    if not p.exists():
        continue
    text = p.read_text(encoding="utf-8")
    for snippet in snippets:
        if snippet.casefold() not in text.casefold():
            errors.append(f"{rel}: missing required content {snippet!r}")

# Catch common accidental secret formats without treating all API terminology as a secret.
secret_patterns = ["-----BEGIN PRIVATE KEY-----", "AKIAIOSFODNN7EXAMPLE", "ghp_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"]
for rel in ["README.md", "docs/MRD.md", "docs/ROADMAP.md", "docs/data-provider-registry.md", "docs/connectivity-test-matrix.md"]:
    p = ROOT / rel
    if p.exists():
        text = p.read_text(encoding="utf-8")
        for pattern in secret_patterns:
            if pattern in text:
                errors.append(f"{rel}: possible credential placeholder/example needs review: {pattern}")

if errors:
    print("AliX documentation validation FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)
print("AliX documentation validation PASSED")

REQUIRED_EXTRA = [
    ROOT / "docs/adr/ADR-012-project-governance-owner-authority.md",
    ROOT / "docs/adr/ADR-013-daily-bale-reporting-engine.md",
    ROOT / "docs/reporting/daily-report-spec.md",
    ROOT / "docs/governance/owner-directives/TEMPLATE.md",
]
for extra_path in REQUIRED_EXTRA:
    assert extra_path.exists() and extra_path.stat().st_size > 100, f"missing/empty: {extra_path}"
for phrase in ["Reporting Engine", "Project Governance & Owner Authority", "ADR-012", "ADR-013", "07:00"]:
    assert phrase in (ROOT / "docs/MRD.md").read_text(encoding="utf-8"), f"missing MRD phrase: {phrase}"
for phrase in ["گزارش روزانه", "Bale", "Owner Directive", "فاز ۱"]:
    assert phrase in (ROOT / "docs/ROADMAP.md").read_text(encoding="utf-8"), f"missing Roadmap phrase: {phrase}"

