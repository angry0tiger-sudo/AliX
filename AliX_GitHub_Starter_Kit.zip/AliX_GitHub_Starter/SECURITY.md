# سیاست امنیتی AliX

## موارد ممنوع در مخزن

- کلید API صرافی، tokenها، رمزها، private keyهای SSH/VPN، فایل secret، config واقعی.
- log یا artifact دارای credential، اطلاعات شخصی، شناسهٔ حساس حساب یا payload محرمانه.
- دادهٔ خبر/شبکهٔ اجتماعی/مدل که مجوز نگهداری یا بازتوزیع آن تأیید نشده است.

## گزارش آسیب‌پذیری

مسائل امنیتی را در Issue عمومی با جزئیات exploit و secret واقعی منتشر نکنید. پیش از تعیین کانال خصوصی مورد تأیید مالک مخزن، فقط یک گزارش حداقلی بدون secret/دادهٔ حساس ثبت کنید و جزئیات را از کانال کنترل‌شده به نگه‌دارندهٔ مخزن منتقل کنید.

## اصول دفاعی

- کمترین سطح دسترسی برای workerها و کلیدها؛ کلید معامله بدون مجوز برداشت.
- جداسازی tenant/account/worker و state writable.
- TLS verification روشن، secrets بیرون از Git و image.
- fail-closed برای دادهٔ نامعتبر، ریسک نامعتبر یا state مبهم سفارش.
- پس از timeout سفارش، retry کور ممنوع؛ ابتدا reconciliation.
- Kill Switch و Absolute Capital Protection Limits مستقل از مدل هستند.


## Bale Reporting Secrets

Treat Bale bot tokens, chat IDs where sensitive, proxy/VPN/SSH credentials, and exchange API keys as secrets. Store them only in local secret management or approved CI secrets for non-production tests. Do not expose tokens, full balances, API responses containing identifiers, or screenshots in Issues/PRs/artifacts. The Bale reporting adapter is notification-only; incoming chat messages must never enable live trading or change risk policy.
