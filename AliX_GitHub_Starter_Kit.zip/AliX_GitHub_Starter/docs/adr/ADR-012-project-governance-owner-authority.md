# ADR-012: Project Governance & Owner Authority

- **Status:** Accepted, subject to versioned change control.
- **Decision owner:** Project Owner.
- **Scope:** Internal AliX requirements, architecture, roadmap, priorities and release authorization.

## Context
Earlier drafts did not define how owner instructions interact with existing internal documents, and how a request for live activation should be handled.

## Decision
The Owner is the final decision authority for internal project decisions. An explicit Owner Directive may amend or supersede an internal document, ADR, roadmap requirement or policy. Every change must be recorded in a GitHub Issue/PR, assess financial/security impact, update affected Markdown/ADR, run required tests, and retain the decision and commit history.

The Owner may authorize a live-release workflow. The runtime starts that approved workflow only when release gates are green, risk supervisor and data/connection health are valid, required credentials exist locally and no legal/contractual barrier applies. A failed mandatory gate produces a reasoned NO-GO and cannot be bypassed by a chat message or model output.

ChatGPT is not a remote executor and has no inherent access to the Owner's local machine, secrets or exchange account. ChatGPT can prepare artifacts and instructions; live actions occur only in the deployed runtime through the approved release path.

## Audit fields
`directive_id`, `owner`, `timestamp`, `affected_docs`, `affected_ADRs`, `risk_impact`, `security_impact`, `required_tests`, `approval_status`, `commit_sha`, `GO/NO-GO`. A live authorization additionally records release/config/model hashes, target environment/exchange/account, active absolute capital limits and rollback plan.

## Consequences
Owner intent can supersede internal project design, while changes remain explicit, auditable and testable. Applicable law, exchange/provider terms, credential security and mandatory runtime safeguards remain binding.
