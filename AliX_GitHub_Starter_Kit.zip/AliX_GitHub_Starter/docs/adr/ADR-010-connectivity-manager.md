# ADR-010: Connectivity Manager با مسیرهای مجاز و قابل ممیزی

**وضعیت:** پذیرفته‌شده از نظر معماری؛ سازگاری transport به آزمون نسخه و محیط وابسته است.

## تصمیم

یک Connectivity Manager مسیرهای Direct، HTTP/HTTPS Proxy، SOCKS Proxy، VPN و SSH Tunnel را تحت route policy نسخه‌بندی‌شده مدیریت می‌کند. هر `service_id` و environment دارای health probe، timeout، retry budget، egress identity، telemetry و فهرست مسیرهای مجاز است.

## مرزهای امنیتی

- این لایه برای دورزدن rate limit، محدودیت جغرافیایی/قراردادی، allowlist یا دسترسی غیرمجاز طراحی نمی‌شود.
- TLS validation خاموش نمی‌شود و secretها در Git نگهداری نمی‌شوند.
- timeout سفارش تا reconciliation مانع retry و route-switch می‌شود.
- transport تنها بعد از test matrix سبز، برای endpoint مشخص `SUPPORTED` محسوب می‌شود.
