# مشارکت در پروژه AliX

## قواعد اجباری

1. هر تغییر باید به Issue و فاز Roadmap مرتبط باشد.
2. هیچ تغییر مستقیمی به `main` انجام نشود؛ از PR استفاده کنید.
3. تغییر در ریسک، order lifecycle، transport، exchange adapter، data provider یا ML feature contract نیازمند تست مرتبط و بازبینی حوزه‌ای است.
4. تغییر قابل توجه در معماری باید ADR داشته باشد.
5. تست‌ها از mock/sanitized fixtures استفاده کنند؛ CI نباید به حساب واقعی یا secret واقعی دسترسی داشته باشد.
6. مجوز و شرایط استفادهٔ داده، مدل، کد و dependency باید در manifest/registry به‌روز شود.
7. هر فاز گزارش جداگانه در `docs/phase-reports/phase-XX.md` تولید می‌کند.

## قالب پیشنهادی نام شاخه

- `feat/<scope>`
- `fix/<scope>`
- `docs/<scope>`
- `test/<scope>`
- `security/<scope>`

## Definition of Done

- معیارهای پذیرش Issue قابل اثبات‌اند.
- CI سبز است و شواهد تست در PR درج شده‌اند.
- Data/license/security impact بررسی شده است.
- مستندات و ADRهای مرتبط به‌روزرسانی شده‌اند.
- rollback و رفتار شکست برای تغییرات عملیاتی مشخص است.


## Owner Directives

Owner directives that alter architecture, release criteria, risk policy or live operations must be recorded using `docs/governance/owner-directives/TEMPLATE.md` and a GitHub Issue/PR. Record financial/security impacts and evidence. A directive does not bypass applicable law, provider conditions or required runtime release gates. Never include secrets or Bale bot tokens.
