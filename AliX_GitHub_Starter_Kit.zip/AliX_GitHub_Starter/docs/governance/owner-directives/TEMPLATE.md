# Owner Directive Template

- directive_id: `OD-YYYY-NNN`
- owner:
- timestamp_utc:
- request_summary:
- affected_scope:
- supersedes:
- affected_docs_and_ADRs:
- risk_impact:
- security_impact:
- legal/provider_terms_impact:
- required_tests:
- rollback_or_recovery:
- owner_approval:
- implementation_issue_or_PR:
- commit_sha:
- status: proposed / approved / implemented / rejected
- final_decision: GO / NO-GO / CONDITIONAL GO

> An Owner Directive may amend internal AliX requirements but does not itself bypass mandatory runtime gates, applicable law, provider terms or release verification. Live authorization also requires a release record.
