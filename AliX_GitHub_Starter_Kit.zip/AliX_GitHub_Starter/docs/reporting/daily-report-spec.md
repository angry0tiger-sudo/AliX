# AliX Daily Report Specification

## Schedule
- Time: `07:00` daily.
- Timezone setting: `reporting.timezone`; IANA timezone name, initialized to `Asia/Tehran` and explicitly owner-configurable.
- Data cutoff: configurable and recorded; data arriving after cutoff is excluded from that report revision.

## Required sections
1. **Executive status:** RUNNING/DEGRADED/HALTED, report time, source cutoff, account/exchange aliases, reconciliation status.
2. **P&L/equity:** daily realized PnL, unrealized PnL, fees, net PnL, cumulative equity/PnL graph.
3. **Trading activity:** entries/exits/closed trade count, wins/losses, average result, open orders and failed/rejected orders.
4. **Capital/risk:** equity and free balance summary, exposure, drawdown, hard-cap utilization and Kill Switch status.
5. **AI/operations:** model/strategy version, data freshness/gaps, Risk Gate rejects, connectivity state, latency/error summaries, news/NLP queue status if enabled.

## Source precedence
- Order fills, trade status and balances must be reconciled against the exchange connector and Freqtrade's trade/order records.
- Decision Ledger explains AI inputs and risk votes, but is not the source of truth for exchange fills.
- If sources disagree, label the affected metrics `DEGRADED / NOT RECONCILED`; do not state definitive PnL.

## Charts
PNG charts generated from the same immutable report snapshot: PnL by day, equity curve, trade count/outcomes, exposure/risk and system health. Include visible time range, currency/unit, generated timestamp and source status.

## Bale delivery
- Dedicated adapter under `integrations/notifications/bale/`; send text and chart image(s), or tested file/document fallback.
- Send only to owner-approved chat IDs. Bot token is secret-mounted and never serialized to report, log or error trace.
- Use logical idempotency `(report_date, account_scope, report_revision)` and bounded backoff. Store queued/sent/failed status.
- Initial implementation is one-way notification only; no command handler can submit an order or adjust risk policy.

## Minimum test cases
- 07:00 normal day, scheduler restart, daylight/timezone change as applicable.
- Duplicate invocation for same report key.
- Bale API downtime, timeout, invalid credentials, file-size/media rejection.
- Unauthorized chat, log redaction, missing metric, stale data, DB/exchange PnL mismatch.
- Synthetic report content is clearly marked TEST and cannot be confused with live performance.
