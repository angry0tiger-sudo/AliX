# گزارش پذیرش فازها

برای هر فاز یک فایل بسازید: `phase-00.md`, `phase-01.md`, …

## قالب الزامی گزارش

- شماره/نام فاز و Issue مربوط
- commit SHA و نسخهٔ ابزارها/dependencyها/model/data
- معیار پذیرش و نتیجهٔ PASS/FAIL برای هر مورد
- گزارش تست و لینک CI
- امنیت، مجوزها، تهدیدها و mitigation
- خطاهای باز و اثر آن‌ها
- rollback/runbook
- تصمیم نهایی: `GO`, `NO-GO` یا `CONDITIONAL GO`
- مسئول بررسی و تاریخ تصویب

- وضعیت گزارش روزانه: timezone، report_id نمونه، تطبیق PnL، ارسال Bale و آزمون خطا (بدون افشای token/chat secret)
- Owner Directiveهای مرتبط، اثر مالی/امنیتی و commit SHA
