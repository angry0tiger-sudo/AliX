# ADR-011: External Data Provider Registry و جداسازی Storeها

**وضعیت:** پذیرفته‌شده.

## تصمیم

دادهٔ عددی بازار/آنچین به External Feature Store و متن خبر/تقویم/social مجاز به News Store و NLP Service وارد می‌شود. همهٔ feedها adapter مستقل، provenance، timestampهای point-in-time، schema/rate-limit policy و license status دارند. Freqtrade/صرافی معامله‌گر منبع حقیقت order/fill/balance باقی می‌ماند.

## قواعد

- provider فقط در وضعیت `approved` قابل فعال‌سازی است.
- TradingView تا وجود مجوز صریح برای non-display/algorithmic use در تصمیم معامله `blocked_for_ai_trading` است.
- scraping غیرمجاز، استفاده از کوکی شخصی یا عبور از quota با تعویض transport ممنوع است.
- ویژگی‌های خبر فقط بر مبنای `available_at <= decision_time` قابل اتصال به نمونهٔ تاریخی هستند.
- افزودن منبع جدید نیازمند license review، contract/freshness tests، SLO، fallback policy و ablation است.
